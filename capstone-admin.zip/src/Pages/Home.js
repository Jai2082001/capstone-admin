const Home = () => {
    return (
        <div>    
            The Admin End
        </div>
    )   
}

export default Home;