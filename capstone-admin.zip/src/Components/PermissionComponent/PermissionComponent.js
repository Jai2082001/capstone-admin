import classes from './PermissionComponent.module.css'
import { useEffect, useState } from 'react';

const PermissionComponent = ({permission}) => {
    console.log(permission);
    const [state, changeState] = useState(false)


    useEffect(()=>{
        fetch(`${process.env.REACT_APP_FETCH_LINK}/organizationDetails`, {
            method: 'GET', 
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'id': permission.OrId                 
            }
        }).then((response)=>{
            return response.json();
        }).then((response)=>{
            console.log(response);
            changeState(response[0])
        })
    }, [])

    const btnHandler = (e) => {
        console.log('Btn Handler')
        fetch(`${process.env.REACT_APP_FETCH_LINK}/${e.target.id}Permissions`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                '_id': permission._id
            }
        }).then((response)=>{
            return response.json()
        }).then((response)=>{
            console.log(response)
            alert('Action Done')
        })
    }

    return (
        <div>

            Permission Requested By {state.OrganizationName}
            Firm contact detail {state.OrganizationRepMail} and {state.OrganizationRepPhoneNumber}
            {permission.Model  && 
                <>
                Permission Descripition: -
                <div>{JSON.stringify(permission.Permission)}</div> 
                </>
            }
            
            <button onClick={btnHandler} id='accept'>Accept</button>
            <button onClick={btnHandler} id='decline'>Reject</button>

        </div>
    )
}

export default PermissionComponent